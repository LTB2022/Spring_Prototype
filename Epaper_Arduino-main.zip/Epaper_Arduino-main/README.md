# Epaper_Arduino

To assign digital pins you must edit them on the "epdif.h" file. The pinouts may be assigned to any digital pin but the pinouts that works in this example is below:

// Pin definition
NOTE: Color description is for reference

//White
#define RST_PIN         12

//Purple
#define BUSY_PIN        11

//Green
#define DC_PIN          10

//Orange
#define CS_PIN          9


